
#include "stm32f1xx_hal.h"

#define PWRON_Pin GPIO_PIN_9
#define PWRON_GPIO_Port GPIOB

void dscope_main(void);
void tx_adc_data(void);
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);
void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc);
void My_TIM2_IRQHandler(void);
void My_TIM3_IRQHandler(void);
void My_RTC_IRQHandler(void);
