/*
 * dscope.c
 *
 *  Created on: 18.12.2020
 *      Author: jouko
 */

#include "stm32f1xx_hal.h"


 	extern ADC_HandleTypeDef hadc1;
 	extern ADC_HandleTypeDef hadc2;
 	extern DMA_HandleTypeDef hdma_adc1;

 	extern TIM_HandleTypeDef htim1;
 	extern TIM_HandleTypeDef htim2;

	extern TIM_HandleTypeDef htim3;

	extern UART_HandleTypeDef huart1;
	extern DMA_HandleTypeDef hdma_usart1_tx;
	extern DMA_HandleTypeDef hdma_usart1_rx;
	extern RTC_HandleTypeDef hrtc;



uint16_t adc_buffer[1000];
uint16_t buffer_ptr=0,adc_5V=0;
uint8_t mode=0x00,sample=0, tx_on=0, samples_ready=0, awd_trigger=0, pre_delay=0,trig_start=0;
uint8_t buf_rx[9],ble_connected=0, start =1,bdmasize=9;
uint8_t tx_buffer[10],stop_frame=1;
uint8_t *tx_data_buffer_ptr=adc_buffer;

static const unsigned int sample_rate[16] = { 1,3,7,19,39,79,199,399,799,1999,3999,7999,19999,39999,49999,59999};
//static const unsigned int sine_pwm[16] = { 0,22,29,42,53,62,69,74,75,74,69,62,53,42,29,22};
static const unsigned int sine_pwm[30] = { 0,10,21,31,41,50,59,67,74,81,87,91,95,98,99,100,99,98,95,91,87,81,74,67,59,50,41,31,21,10};
//static const unsigned int triangle_pwm[16] = { 0,10,20,30,40,50,60,70,80,90,10,10,10,10,00,00};
static const unsigned int triangle_pwm[30] = { 0,90,90,90,95,95,95,95,95,98,99,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t		sine_ptr=0,pwm_inton=0;
uint16_t trigger_level=2048;

void tx_adc_data(void);
void start_sampling(void);
void command(void);
void adc_circular_dma_start(void);
void ms_delay(uint16_t mseconds);
void battery_test(void);



void dscope_main(void)
{
	// ADC calibration
	  HAL_ADCEx_Calibration_Start(&hadc1);
  	  HAL_ADCEx_Calibration_Start(&hadc2);

  	  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);   // sinewave pwm
  	  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);	// triangle pwm
 // 	  HAL_TIM_Base_Start_IT(&htim2);   // timer2 interrupts enable
  	  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);	// pwm
 	  battery_test();
  	  HAL_ADC_Start(&hadc2);
  	 // dual channel adc1 and 2 DMA sampling
  	  HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buffer,500);
  	  //		Timer1 CCR1 sampling clock
  	  //HAL_TIM_Base_Start(&htim1);
 	  //HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
 	  // start rx uart dma
 	  HAL_UART_Receive_DMA(&huart1, buf_rx, 9); // wait for OK+CONN(CR)(LF)




  while (1)
  {

	  	  command();
	  // UART1 transmit DMA ADC data
	   	  tx_adc_data();

   }


}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

	if ((buf_rx[0]=='O')&&(buf_rx[1]=='K')){
		if ((buf_rx[3]=='C')&&(buf_rx[4]=='O')) {
			ble_connected=1;
			bdmasize=6;
		} else if ((buf_rx[3]=='L')&&(buf_rx[4]=='O')&&(buf_rx[5]=='S')){
			ble_connected=0;
			bdmasize=9;
		}
		HAL_UART_Receive_DMA(&huart1, buf_rx, bdmasize);
	} else {
		if ((bdmasize ==1) && (buf_rx[0]==0x2b)){
			bdmasize=6;
			HAL_UART_Receive_DMA(&huart1, (buf_rx+1) ,5);
		} else {
			if ((buf_rx[0]==0x2b)&&(buf_rx[5]==0x23)){
				sample = (buf_rx[2] & 0x0f);
				mode = buf_rx[1];
				trigger_level = (buf_rx[3] & 0x00ff)|((buf_rx[4] & 0x000f)<<8);
				start =1;
			} else if (buf_rx[0]!=0x2b){
				bdmasize=1;
			}
			HAL_UART_Receive_DMA(&huart1, buf_rx, bdmasize);
		}
	}
}

void tx_adc_data(void)
{
	 // UART1 transmit DMA ADC data
	if ((tx_on==0)&&(samples_ready==1))
	{
		tx_on = 1;
		uint8_t tx_header[2] = {0x2B,0x01};
	 	HAL_UART_Transmit(&huart1, tx_header, 2, 5);
	 	if ((mode & 0x80) && !(mode & 0x10)){
	 		HAL_UART_Transmit_DMA (&huart1, adc_buffer, 2000);
	 	}else{
	 		HAL_UART_Transmit_DMA (&huart1, adc_buffer, 2000);

	 	}
	}

}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
		uint8_t data_end[2] = {0xff,0xff};
		HAL_UART_Transmit(&huart1, data_end, 2, 5);
		tx_on =0;
		samples_ready =0;
		HAL_UART_Receive_DMA(&huart1, buf_rx, 6);

}
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{

//	DMA1->IFCR = DMA1->ISR;		//clear DMA int flags
	if (!(DMA1_Channel1->CCR & 0x00000020U))   // single mode
	{
			HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
			samples_ready =1;
	} else {

		if (pre_delay==0){
			pre_delay=1;
			ADC1->SR &= ~(0x00000001U);				// AWD int flag clear
			ADC1->CR1 |= 0x00800040U;				// AWD1 int enable
		} else {
			if (awd_trigger==1){
				HAL_ADC_Stop_DMA(&hadc1);
				HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
				buffer_ptr = (uint16_t)DMA1_Channel1->CNDTR;  //  how many left?
				samples_ready =1;
				DMA1_Channel1->CCR &= ~(0x00000002U); 	// complete int disable
				pre_delay=0;
				awd_trigger=0;
				trig_start=0;
			}
		}
	}
}

void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc)
{
//	DMA1->IFCR = DMA1->ISR;     			//clear DMA int flags
/*	if (awd_trigger==1){
					HAL_ADC_Stop_DMA(&hadc1);
					HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
					buffer_ptr = (uint16_t)DMA1_Channel1->CNDTR;  //  how many left?
					samples_ready =1;
					DMA1_Channel1->CCR &= ~(0x00000004U); 	// half complete int disable
					pre_delay=0;
					awd_trigger=0;
					trig_start=0;
	} else if (pre_delay==0){

		pre_delay=1;
		ADC1->SR &= ~(0x00000001U);				// AWD int flag clear
		ADC1->CR1 |= 0x00800040U;				// AWD1 int enable
	}*/
}


void HAL_ADC_LevelOutOfWindowCallback(ADC_HandleTypeDef* hadc)
{
	if (!(trig_start)){				  //trigger rising/falling not active

		if ((mode & 0x40)){					// trigger rising
					ADC1->HTR = trigger_level;	// over trigger level
					ADC1->LTR = 0;
		}else{								//trigger falling
					ADC1->LTR = trigger_level;   // below trigger level
					ADC1->HTR = 4095;
		}
		trig_start=1;
	} else {

		awd_trigger=1;
		ADC1->CR1 &= ~(0x00000040U);				// AWD int disable

	}
}



void start_sampling(void)
{
	if (sample==0){

		RCC->CFGR &= ~(0x0000C000U);	// ADC clock 28 MHz
		ADC1->SMPR2 &= ~(0x00000007U);	// sample time 1.5 cycles
		ADC2->SMPR2 &= ~(0x00000038U);
		ADC2->CR2 |= 0x00000002U;		// continuous conversions 0,5 us
		ADC1->CR2 |= 0x00000002U;
	} else {
		RCC->CFGR |= 0x00004000U;  	// ADC clock 14 MHz
		if (sample==1){
			ADC1->SMPR2 &= ~(0x00000007U);	// sample time ch0 1.5 cycles
			ADC2->SMPR2 &= ~(0x00000038U);
			ADC2->CR2 |= 0x00000002U;		// continuous conversions 1 us
			ADC1->CR2 |= 0x00000002U;
		} else {
			if (sample ==2) {
				ADC1->SMPR2 |= 0x00000002U;		// sample time ch0 13.5 cycles
				ADC2->SMPR2 |= 0x00000010U;		// sample time ch1 13.5 cycles
			} else{
				ADC1->SMPR2 |= 0x00000003U;		// sample time ch0 28.5 cycles
				ADC2->SMPR2 |= 0x00000018U;		// sample time ch1 28.5 cycles

			}
			ADC2->CR2 &= ~(0x00000002U);		// single conversion 2... us
			ADC1->CR2 &= ~(0x00000002U);
		}
	}
	if ((mode & 0x80)&&(mode & 0x10)){				// single trigger?
		DMA1_Channel1->CCR |= 0x00000022U;       // DMA circular mode ,complete conv int

		if (!(mode & 0x40)){					// trigger high
				ADC1->HTR = trigger_level;
				ADC1->LTR = 0;
		}else{								//trigger low
				ADC1->LTR = trigger_level;
				ADC1->HTR = 4095;
		}
//		ADC1->CR1 |= 0x00800040U;  //Analog WD enable int
		HAL_ADC_Start(&hadc2);
		  	  // dual channel adc1 and 2 DMA sampling
		adc_circular_dma_start();

	}else{
		DMA1_Channel1->CCR &= ~(0x00000020U);	// DMA single mode
		DMA1_Channel1->CCR |= (0x00000002U);	// Transfer complete int enable
		ADC1->CR1 &= ~(0x00000040U);			// AWD int disable
		HAL_ADC_Start(&hadc2);
		  	  // dual channel adc1 and 2 DMA sampling
		HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buffer,500);

	}


  	  //		Timer1 CCR1 sampling clock
  	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  	HAL_TIM_Base_Start(&htim1);
}

void set_smps(void)
{
	// set sample rate period to auto reload register
    HAL_TIM_Base_Stop(&htim1);

	TIM1->ARR = sample_rate[sample];
}

void command(void)
{
	if ((mode & 0x01))     // DC AC select
	{
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_SET);
	} else{
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
	}
	if ((mode & 0x02)&& (pwm_inton==0))     // timer 2 pwm out on/off
		{
			pwm_inton=1;
			HAL_TIM_Base_Start_IT(&htim2);
		} else if (!(mode & 0x02)&& (pwm_inton==1)){
			pwm_inton=0;
			HAL_TIM_Base_Stop_IT(&htim2);
		}


	if (start==1)
	{
		start=0;
		set_smps();
		start_sampling();

	}
}

void adc_circular_dma_start()
{
	DMA1_Channel1->CCR &= ~(0x00007fffU);		// Transfer complete int disable
	DMA1_Channel1-> CNDTR = 500;				// dma count 500
	DMA1_Channel1-> CPAR = 0x4001244cU ;
	DMA1_Channel1-> CMAR = (uint32_t*)adc_buffer ;
	DMA1_Channel1->CCR |= (0x00002aa0U);		// dma adc1 circular enable, no interrupt
	DMA1_Channel1->CCR |= (0x00000023U);		// dma adc1 circular enable, cplt transfer int
	ADC1->SR &= ~(0x00000001U);					// AWD int flag clear
	ADC1->CR1 &= ~(0x00000040U);				// AWD int disable
	ADC1->CR2 |= 0x00100100U;					// ADC1 dma and extrig
	ADC1->CR2 |= 0x00000001U;					// ADC1 start
	pre_delay=0;								// wait sampling to buffer

}


void ms_delay(uint16_t mseconds)
{
	while (mseconds-- > 0){
		uint16_t mscounter = 1000;
		while (mscounter-- > 0)
		{
			__ASM volatile ("NOP");
			__ASM volatile ("NOP");
		}

	}
}

void battery_test()
{
	uint32_t ad1_cr1_save;
	uint32_t ad1_cr2_save;

	ad1_cr1_save = ADC1->CR1;   // Save ADC1 control registers
	ad1_cr2_save = ADC1->CR2;

	ADC1->SQR3 = 0x00000007U;			// ADC1 channel7 in
	ADC1->SMPR2 = 0x00e00000U;			// long sample time
	ADC1->CR1 = 0x00000000U;
	ADC1->CR2 = 0x004e0001U;			    // single conversion , sw start
	ms_delay(10);

	ADC1->CR2 |= 0x00000001U;					// ADC2 start
//	HAL_ADC_Start(&hadc1);
	while (!(ADC1->SR && 0x00000002U));
	adc_5V = ADC1->DR;
	if (adc_5V < 2700)
	{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
	} else{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);
	}
	ADC1->SQR3 = 0x00000000U;			// ADC1 channel0 input
	ADC1->CR1 = ad1_cr1_save;   // Restore ADC1 control registers
	ADC1->CR2 = ad1_cr2_save;

}

void  HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
	HAL_TIM_Base_Stop_IT(&htim2);   // timer2 interrupts enable

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); 	//power off

	ms_delay(1000);
}

void My_RTC_IRQHandler(void)
{
	HAL_TIM_Base_Stop_IT(&htim2);   // timer2 interrupts enable

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); 	//power off

	ms_delay(1000);
}


void My_TIM2_IRQHandler(void)
{
	      // Timer 2  period elapsed
		TIM2->SR &= 0xFFFFFFFEU;    //UIF flag clear
		TIM2->CCR2 = triangle_pwm[sine_ptr];
		TIM2->CCR1 = sine_pwm[sine_ptr++];  // PWM value
		if (sine_ptr > 30) sine_ptr = 0;

}

void My_TIM3_IRQHandler(void)
{


}


